package com.example.flutter_application_prova_clinica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
